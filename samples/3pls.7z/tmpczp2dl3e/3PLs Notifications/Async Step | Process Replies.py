# Databricks notebook source
# MAGIC %md
# MAGIC ## Async Step - 
# MAGIC
# MAGIC ### What this step does?
# MAGIC
# MAGIC - This step is triggered with via Zapier with a fixed - parameter_s3_path - which is the place where parameters file is present, we will read that file and get the parameters
# MAGIC - Parameters List:
# MAGIC     - in_reply_to_header
# MAGIC     - conversation_id
# MAGIC     - conversation_body
# MAGIC - We will parse the conversation body - get the required details and then send out those details to the LLMs so that we can parse the details that we need to merge into the ISSUE_TRACKER table

# COMMAND ----------

# MAGIC %md
# MAGIC ### Accessing the important job parameters - without these the jobs will fail -

# COMMAND ----------

# MAGIC %pip install openai
# MAGIC %pip install -U mlflow
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import mlflow
import os
from openai import OpenAI

mlflow.openai.autolog()

# COMMAND ----------

# DBTITLE 1,AI client inits
# !TODO - Need to fix these
API_KEYS = [
    os.getenv("OPENAI_API_KEY"),
    "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",
    "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",
    "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",
]
CURRENT_INDEX = 0
MODEL_ID = "google/gemini-2.5-flash"

# COMMAND ----------

def get_api_key(pre_api_key=None):
    global CURRENT_INDEX
    n = len(API_KEYS)
    if n == 0:
        raise Exception("No API keys available")
    
    # Start from the current index and cycle through the list
    # Try up to n times to find a valid key
    for _ in range(n):  
        key = API_KEYS[CURRENT_INDEX]
        
        # Check if key is valid and not matching pre_api_key (if provided)
        if key is not None and key != "" and (pre_api_key is None or key != pre_api_key):
            selected_key = key
            # Rotate to the next index for future calls
            CURRENT_INDEX = (CURRENT_INDEX + 1) % n
            return selected_key
        
        # Move to next if invalid or matching
        CURRENT_INDEX = (CURRENT_INDEX + 1) % n
    
    raise Exception("No valid API key found")


# COMMAND ----------

def refresh_openai_client(api_key):
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1/",
        api_key=api_key,
    )

    return client

# COMMAND ----------

API_KEY = get_api_key()
client = refresh_openai_client(API_KEY)

# COMMAND ----------

# DBTITLE 1,job parameters access
dbutils.widgets.text("parameters_s3_path", "")

parameters_s3_path = dbutils.widgets.get("parameters_s3_path")
print(parameters_s3_path)

if not parameters_s3_path:
    raise Exception("parameter not present")

# COMMAND ----------

# DBTITLE 1,libraries import and session initialization
import boto3
import json
import re
import time

INGESTION_BUCKET = "tushar-testing"
ISSUE_TRACKER_TABLE = "logistics_data.mappings.issue_tracker"
LOGISTICS_TRANSIENT_TABLE = "data_team_test.test_schema.logistics_transient_table"

session = boto3.Session(
    dbutils.secrets.get("AWS-Admin", "access-key"),
    dbutils.secrets.get("AWS-Admin", "secret-key"),
)

# COMMAND ----------

# DBTITLE 1,get_parameters_string
def get_parameters_string():
    s3 = session.client("s3")
    obj = s3.get_object(Bucket=INGESTION_BUCKET, Key=parameters_s3_path)

    return obj["Body"].read().decode("utf-8")

# COMMAND ----------

# DBTITLE 1,get 0th message details
def get_0th_message(conversation_body):
    """
    This function will return the 0th message from the conversation_body which is received from the Microsoft Graph API
    """
    return conversation_body["value"][0]

# COMMAND ----------

# DBTITLE 1,create conversation details array
def get_conversation_details(conversation_body):
    """
    This function will return the details of the conversation using the conversation_body which is received from the Microsoft Graph API --

    - Conversation details -
        Array of
            - id - message_id
            - body - message_body
            - subject - message_subject
            - sender - message_sender
            - receivedDateTime - message_receivedDateTime
            - from - message_from
            - toRecipients - message_toRecipients
            - ccRecipients - message_ccRecipients
            - bccRecipients - message_bccRecipients
    """

    conversation_details = []

    for message in conversation_body["value"]:
        trimmed_message = {}

        trimmed_message["id"] = message["id"]
        trimmed_message["body"] = message["body"]["content"]
        trimmed_message["subject"] = message["subject"]
        trimmed_message["sender"] = (
            f"{message["sender"]["emailAddress"]["name"]} <{message["sender"]["emailAddress"]["address"]}>"
        )
        trimmed_message["receivedDateTime"] = message["receivedDateTime"]
        trimmed_message["from"] = (
            f"{message["from"]["emailAddress"]["name"]} <{message["from"]["emailAddress"]["address"]}>"
        )
        trimmed_message["toRecipients"] = []
        for recipient in message["toRecipients"]:
            trimmed_message["toRecipients"].append(
                f"{recipient["emailAddress"]["name"]} <{recipient["emailAddress"]["address"]}>"
            )
        trimmed_message["ccRecipients"] = []
        for recipient in message["ccRecipients"]:
            trimmed_message["ccRecipients"].append(
                f"{recipient["emailAddress"]["name"]} <{recipient["emailAddress"]["address"]}>"
            )
        trimmed_message["bccRecipients"] = []
        for recipient in message["bccRecipients"]:
            trimmed_message["bccRecipients"].append(
                f"{recipient["emailAddress"]["name"]} <{recipient["emailAddress"]["address"]}>"
            )

        conversation_details.append(trimmed_message)
    return conversation_details

# COMMAND ----------

# DBTITLE 1,system prompt and input prompt
def get_system_and_input_prompt(conversation_json):
    """
    Returns System Prompt and Input Prompt for the model
    aligned with the response_schema definition
    """

    system_prompt = """You are an AI assistant specialized in analyzing email conversations between our team and 3PL (Third Party Logistics) providers regarding shipment discrepancies.

Analyze the provided email thread where:
1. Our team reports a discrepancy to the 3PL.
2. The 3PL responds with clarification or resolution details.

Extract the following fields exactly as defined in the schema:

- issue: Must be one of ["Overstock", "Short_Stock", "Wrong_Stock", "Damaged", "Delayed"].
- email_subject: Subject line of the conversation.
- complaint_category: Must always be "Order & Shipment Accuracy".
- complaint_sub_category: Must be one of the predefined sub-categories under "Order & Shipment Accuracy".
- details_or_comments: A detailed but concise summary of the problem and the 3PL’s response. Capture all key points factually.
- source_of_complaint: Must be one of ["3PL", "SAP", "Customer", "Unknown"].
- approximate_resolving_time: The resolving time if explicitly mentioned (e.g., "2 days", "next week"). Otherwise, "Unknown".

Guidelines:
- Only return values that are valid according to the schema.
- If information is missing or unclear, use "Unknown".
- Use professional, concise language.
- Return JSON only, without markdown formatting, comments, or extra text.
"""

    input_prompt = f"""
TASK:
From the conversation JSON below, extract the fields exactly as described in the system prompt.
Only use allowed enum values where specified. Use "Unknown" for missing details.

INPUT:
<conversation_json>
{conversation_json}
</conversation_json>

OUTPUT FORMAT:
Return only a JSON object with the following fields:
[
  "issue",
  "email_subject",
  "complaint_category",
  "complaint_sub_category",
  "details_or_comments",
  "source_of_complaint",
  "approximate_resolving_time"
]
"""

    return (system_prompt, input_prompt)

# COMMAND ----------

# DBTITLE 1,response schema
def get_response_schema():
    """
        Returns the response schema to which is passed on to the User - 
    """
    response_schema = {
        "name": "extract_complaint_details",
        "description": "Extract complaint-related details from a Microsoft Graph email conversation JSON",
        "parameters": {
            "type": "object",
            "properties": {
                "issue": {
                    "type": "string",
                    "enum": [
                        "Overstock",
                        "Short_Stock",
                        "Wrong_Stock",
                        "Damaged",
                        "Delayed",
                    ],
                    "description": "Short description of the issue raised in the conversation. Must be one of: Overstock, Short_Stock, Wrong_Stock, Damaged, Delayed.",
                },
                "email_subject": {
                    "type": "string",
                    "description": "Subject line of the conversation",
                },
                "complaint_category": {
                    "type": "string",
                    "enum": [
                        "Order & Shipment Accuracy",
                    ],
                    "description": "Primary category of the complaint. Must be 'Order & Shipment Accuracy'.",
                },
                "complaint_sub_category": {
                    "type": "string",
                    "enum": [
                        "Overage",
                        "Canceled PO",
                        "Canceled Line",
                        "Item Not on PO",
                        "Wrong Pack",
                        "Duplicate Shipments",
                        "Late Delivery",
                        "Recall/Withdrawal",
                        "Date Issue",
                        "Not customer's Freight/Incorrect item received",
                        "ASN related Issues",
                        "Rework",
                        "Allocation Issue",
                        "Imagery (Dotcom only)",
                        "Item Setup",
                        "ParentChild",
                    ],
                    "description": "Specific sub-category of the complaint. Must be one of the provided sub-categories for 'Order & Shipment Accuracy'.",
                },
                "details_or_comments": {
                    "type": "string",
                    "description": "Detailed summary of the problem and reply from the 3PL. Include any relevant details or comments that were exchanged in the response in a very detailed manner (LC's use it to refer to some other).",
                },
                "source_of_complaint": {
                    "type": "string",
                    "enum": ["3PL", "SAP", "Customer", "Unknown"],
                    "description": "Source of the complaint, where the complaint was sourced from",
                },
                "approximate_resolving_time": {
                    "type": "string",
                    "description": "Estimated resolving time if mentioned, otherwise 'Unknown'",
                },
            },
            "required": [
                "issue",
                "email_subject",
                "complaint_category",
                "complaint_sub_category",
                "details_or_comments",
                "source_of_complaint",
                "approximate_resolving_time",
            ],
        },
    }

    return response_schema

# COMMAND ----------

# DBTITLE 1,clean ai markdown slop
def clean_ai_markdown_slop(response_content):
    """
        Returns clean content from AI that is devoid of any jargonish and markdown backticks slop
    """

    return re.sub(r"^```(?:\w+)?\n|```$", "", response_content, flags=re.MULTILINE).strip()

# COMMAND ----------

# DBTITLE 1,parse mail using ai
def parse_mail_using_ai(conversation_json):
    global API_KEY, client

    max_retries = 3
    raw = ""
    parsed_response = None

    for attempt in range(0, max_retries):
        try:
            system_prompt, input_prompt = get_system_and_input_prompt(
                conversation_json=conversation_json
            )

            response_schema = get_response_schema()

            response = client.chat.completions.create(
                model=MODEL_ID,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": input_prompt},
                ],
                temperature=0.4,
                reasoning_effort="high",
                response_format=response_schema,
            )

            print("======")

            print(response.choices[0].message.content)

            print("======")
            raw = clean_ai_markdown_slop(response.choices[0].message.content.strip())
            parsed_response = json.loads(raw)

            return parsed_response
        except Exception as e:
            if attempt == max_retries:
                raise Exception(
                    f"LLM calls failed after {attempt} attempts: {raw}"
                ) from e

            # Optional delay and refresh hook
            print(f"\nLLM calls failed, retrying...:: {e} :: {raw}\n")

            time.sleep(0.5)
            API_KEY = get_api_key(pre_api_key=API_KEY)
            client = refresh_openai_client(API_KEY)

# COMMAND ----------

# DBTITLE 1,validate ai response
def validate_ai_response(response: dict) -> bool:
    """
    Validate AI response dictionary to ensure required fields are present and non-empty.
    
    Raises:
        ValueError: If any required field is missing or empty.
    """
    required_fields = [
        "issue",
        "email_subject",
        "complaint_category",
        "complaint_sub_category",
        "details_or_comments",
        "source_of_complaint",
        "approximate_resolving_time",
    ]
    
    for field in required_fields:
        if field not in response:
            raise ValueError(f"Missing required field: {field}")
        if response[field] is None or str(response[field]).strip() == "":
            raise ValueError(f"Field '{field}' cannot be empty")


# COMMAND ----------

# DBTITLE 1,merge into issue tracker
def merge_records_into_issue_tracker(
    response, in_reply_to_header, conversation_id, zeroth_message_weblink
):
    """
    Safely merges the response from AI into the issue tracker for the appropriate order IDs,
    using Spark SQL parameter substitution (avoids SQL injection and escaping errors).
    """

    params = {
        "issue": response.get("issue"),
        "email_subject": response.get("email_subject"),
        "complaint_category": response.get("complaint_category"),
        "complaint_sub_category": response.get("complaint_sub_category"),
        "details_or_comments": response.get("details_or_comments"),
        "source_of_complaint": response.get("source_of_complaint"),
        "approximate_resolving_time": response.get("approximate_resolving_time"),
        "in_reply_to_header": in_reply_to_header,
        "conversation_id": conversation_id,
        "zeroth_message_weblink": zeroth_message_weblink,
    }

    query = f"""
        MERGE INTO {ISSUE_TRACKER_TABLE} AS target
        USING (
            SELECT *
            FROM {LOGISTICS_TRANSIENT_TABLE}
            WHERE processed = TRUE
              AND message_id IS NOT NULL
              AND instr(:in_reply_to_header, message_id) > 0
        ) AS source
        ON target.sap_zsdt019_id = source.id
        WHEN MATCHED THEN
          UPDATE SET 
            target.issue = :issue,
            target.email_subject = :email_subject,
            target.last_updated = CURRENT_TIMESTAMP,
            target.complaint_category = :complaint_category,
            target.complaint_sub_category = :complaint_sub_category,
            target.details_or_comments = :details_or_comments,
            target.source_of_complaint = :source_of_complaint,
            target.approximate_resolving_time = :approximate_resolving_time,
            target.issue_identified_date = source.ingestion_date
        WHEN NOT MATCHED THEN
          INSERT (
              sap_zsdt019_id,
              issue,
              email_subject,
              last_updated,
              complaint_category,
              complaint_sub_category,
              details_or_comments,
              source_of_complaint,
              approximate_resolving_time,
              email_conversation_id,
              email_link,
              issue_identified_date,
              first_response_date
          )
          VALUES (
              source.id,
              :issue,
              :email_subject,
              CURRENT_TIMESTAMP,
              :complaint_category,
              :complaint_sub_category,
              :details_or_comments,
              :source_of_complaint,
              :approximate_resolving_time,
              :conversation_id,
              :zeroth_message_weblink,
              source.ingestion_date,
              to_date(CURRENT_TIMESTAMP)
          )
    """
    
    spark.sql(query, params)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Main

# COMMAND ----------

# DBTITLE 1,MAIN
parameters_string = get_parameters_string()

if not parameters_string:
    raise Exception("No parameters found")

# JSON parse it -
parameters = json.loads(parameters_string)
in_reply_to_header = parameters.get("inReplyToValue")
conversation_id = parameters.get("conversationId")
conversation_body = json.loads(parameters.get("conversationBody", "{}"))

if not in_reply_to_header:
    raise Exception("No in reply to header found")
if not conversation_id:
    raise Exception("No conversation id found")
if not conversation_body or len(conversation_body.items()) == 0:
    raise Exception("No conversation body found")

# Validate if the conversation_body has value field and it should be an array
if "value" not in conversation_body:
    raise Exception("No value field found in conversation_body")
if not isinstance(conversation_body["value"], list):
    raise Exception("value field in conversation_body is not an array")

print(in_reply_to_header)
print(conversation_id)
print(conversation_body)

# COMMAND ----------

# DBTITLE 1,prepare the conversation details
conversation_details = get_conversation_details(conversation_body)
conversation_json = json.dumps(conversation_details)

zeroth_message = get_0th_message(conversation_body)
zeroth_message_weblink = zeroth_message.get("webLink", "Unknown")

# COMMAND ----------

# DBTITLE 1,ai calls to parse the mails structure
parsed_response = parse_mail_using_ai(conversation_json)
validate_ai_response(parsed_response)

# COMMAND ----------

# DBTITLE 1,merge the records into the  issue tracker
merge_records_into_issue_tracker(
    parsed_response,
    in_reply_to_header=in_reply_to_header,
    conversation_id=conversation_id,
    zeroth_message_weblink=zeroth_message_weblink,
)