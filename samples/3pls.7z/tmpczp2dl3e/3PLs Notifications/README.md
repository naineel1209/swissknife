#AI enabled 3PLs notifications Workflow

## Steps
1. Create a Custom View upon the `sap_zsdt019` table that precalculates the required data
- Store the Custom View in `data_team_test.test_schema.sap_zsdt019_custom_view`, we will change this later
- We will create a VIEW and not a materialised view as we want the data to be fetched essentially from the unnderlying table and not the materialised view where the data might get stale everyday

2. Schedule an ETL job every week that queries Custom View for records with:

### Identify the qualifying records
– quantity > 0
– return_reasons IS NOT NULL
-	customer_request_ship_date <= Today()
and the record should not be present in the TRANSIENT table

  We will evaluate the following fields for the records passing above check
  - shortage - quantity  - shipping_quantity
  - delay_days = date_diff(actual_shipping_date, customer_ship_request_date)

  ```sql
    SELECT
      count(*)
    FROM
      data_team_test.test_schema.sap_zsdt019_custom_view -- custom view upon the sap-data.pisummary.sap_zsdt019
    WHERE
      quantity > 0
      AND return_reasons IS NULL
      AND customer_request_ship_date_parsed <= date_sub(current_date(), 0)
      AND (
        shortage > 0
        OR delay_days > 0
      )
  ```

### Insert the qualifying records into the Transient Table

```csv
Field, Description
3PL_name,	Derived from storage/storage_desc
key_type,	One of delivery_note_no,sales_order,customer_po_num
key_value,	Corresponding ID value
delivery_note_n,  	
sales_order,	
customer_po_num,	
shortage,	Computed shortage
delay_days,	Computed delay
processed, (BOOLEAN)	Default FALSE
created_date item_No	Source metadata
Timestmap, 	When issue was observed
```

3. Now, we will only process those records which are `processed: false` - we will send out the mails for the affecting 3PLs
But we need to group them according to its delivery note number, sales order or customer po number

Based on that we will send out one mail for each discrepancy record (and the way we grouped the data)

We will  mark the record as processed - and create an entry in the email logs table 

4. Email Logs Table - 
We will create a table with the following fields:

```sql
CREATE TABLE email_logs (
    email_log_id STRING PRIMARY KEY,
    original_record_ids ARRAY<INT>,  -- Links to logistics_transient_table IDs
    key_type STRING,                 -- deliv_note_no, sales_order, customer_po_num
    key_value STRING,               -- Actual key value
    storage STRING,                 -- Warehouse storage code
    contact_email STRING,           -- 3PL contact email
    contact_name STRING,            -- 3PL contact name
    email_type STRING,              -- 'initial', 'follow_up_1', 'follow_up_2'
    parent_email_id STRING,         -- Links to original email for follow-ups
    email_subject STRING,
    email_body STRING,
    attachment_paths ARRAY<STRING>,
    sent_timestamp TIMESTAMP,
    aws_message_id STRING,          -- SES Message ID
    response_received BOOLEAN DEFAULT FALSE,
    response_timestamp TIMESTAMP,
    response_content STRING,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA;
```
And store the email_log_id in the transient table to establish a replationship.

Every day we will process a script to check if there are any mails which needs follow ups (that is - we have not received any replies from the 3PLs - after 1. 5 days (first follow up) and 2. 10 days (second follow up) and any escalations - (we will stop the follow up chain here and mark it completed and then follow up )) Escalations will be added to another table which will be notified to you via mails or any other options.



## Asynchronous Workflow:

An asynchronous Zapier or someother script workflow which runs on arrival of every email and checks if the mail is a reply to another mail - if it is then check if the parent message id is present in our email_logs table - get the contents of the email logs mail and then get the reply from the 3PL - make a prompt out of it, send it to AI and then process it such that to receive the details like 
- Reason for delay/short-ship
- Any corrective action or ETA

Mark the source and other details from the reply mail and update the sales order issue tracker table. If any details are missing - then follow up mail to the 3PL