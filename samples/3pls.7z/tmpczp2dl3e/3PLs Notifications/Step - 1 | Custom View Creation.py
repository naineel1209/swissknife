# Databricks notebook source
# MAGIC %md
# MAGIC ## Step 1: Custom View Creation
# MAGIC
# MAGIC - Custom View (not materialized) to help with custom typed columns on the base `sap-data.pisummary.zsdt019`
# MAGIC - This is a one time script and does not need to run daily
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW data_team_test.test_schema.sap_zsdt019_custom_view AS
# MAGIC SELECT
# MAGIC   id,
# MAGIC   sku,
# MAGIC   long_desc,
# MAGIC   brand,
# MAGIC   brand_desc,
# MAGIC   sales_order,
# MAGIC   deliv_note_no,
# MAGIC   delivery_address,
# MAGIC   customer_po_num,
# MAGIC   cutomer_name_sold_to,
# MAGIC   quantity,
# MAGIC   shipping_quantity,
# MAGIC   (quantity - shipping_quantity) AS shortage,
# MAGIC   customer_request_ship_date,
# MAGIC   -- SAFE DATE PARSING
# MAGIC   CAST(
# MAGIC     try_to_timestamp(customer_request_ship_date, 'yyyyMMdd') AS DATE
# MAGIC   ) AS customer_request_ship_date_parsed,
# MAGIC   actual_shipping_date,
# MAGIC   -- SAFE DATE DIFF (only when parsed date is valid)
# MAGIC   date_diff(
# MAGIC     actual_shipping_date, CAST(try_to_timestamp(customer_request_ship_date, 'yyyyMMdd') AS DATE)
# MAGIC   ) AS delay_days,
# MAGIC   storage,
# MAGIC   storage_desc,
# MAGIC   data_createtime,
# MAGIC   item_No,
# MAGIC   sales_org,
# MAGIC   created_date,
# MAGIC   return_reasons
# MAGIC FROM
# MAGIC   `sap-data`.pisummary.sap_zsdt019