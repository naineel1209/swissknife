# Databricks notebook source
# MAGIC %md
# MAGIC ## Step - 2: Creation Of Transient Tables
# MAGIC
# MAGIC Please checkout the complete workflow at -@/Confluence Documentation
# MAGIC
# MAGIC - What we do here?
# MAGIC   - Get the table values from the custom view and filter those records which have a valid entry in the 3PLs table
# MAGIC   - Now perform an Anti-Join on the base output transient table records so that only those elements which are not present in the base table are appended to the base catalog

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS data_team_test.test_schema.logistics_transient_table (
# MAGIC     id INT,
# MAGIC     sku STRING,
# MAGIC     long_desc STRING,
# MAGIC     brand STRING,
# MAGIC     brand_desc STRING,
# MAGIC
# MAGIC     -- sales-order-description
# MAGIC     sales_order STRING,
# MAGIC
# MAGIC     -- deliv_note_no
# MAGIC     deliv_note_no STRING,
# MAGIC     delivery_address STRING,
# MAGIC     
# MAGIC     -- customer_po_num
# MAGIC     customer_po_num STRING,
# MAGIC     cutomer_name_sold_to STRING,
# MAGIC     
# MAGIC     quantity DECIMAL(38,18),
# MAGIC     shipping_quantity DECIMAL(38,18),
# MAGIC     shortage DECIMAL(38,17),
# MAGIC     customer_request_ship_date STRING,
# MAGIC     customer_request_ship_date_parsed DATE,
# MAGIC     actual_shipping_date TIMESTAMP,
# MAGIC     delay_days INT,
# MAGIC     storage STRING,
# MAGIC     storage_desc STRING,
# MAGIC     data_createtime TIMESTAMP,
# MAGIC     item_No DECIMAL(38,18),
# MAGIC     sales_org STRING,
# MAGIC     created_date TIMESTAMP,
# MAGIC     return_reasons STRING,
# MAGIC     key_type STRING NOT NULL,
# MAGIC     key_value STRING,
# MAGIC     processed BOOLEAN NOT NULL,
# MAGIC     ingestion_date DATE NOT NULL,
# MAGIC     message_id STRING
# MAGIC ) USING DELTA;

# COMMAND ----------

OUTPUT_TRANSIENT_TABLE = "data_team_test.test_schema.logistics_transient_table"
THREE_PL_TABLE = "data_team_test.test_schema.three_pl_information"

# COMMAND ----------

base_df = spark.sql(
    """
SELECT
  *,
  CASE
    WHEN deliv_note_no IS NOT NULL THEN "deliv_note_no"
    WHEN sales_order IS NOT NULL THEN "sales_order"
    ELSE "customer_po_num"
  END as key_type,
  coalesce(
    cast(deliv_note_no as string), cast(sales_order as string), cast(customer_po_num as string)
  ) AS key_value,
  FALSE AS processed,
  current_date() AS ingestion_date,
  NULL AS message_id
FROM
  data_team_test.test_schema.sap_zsdt019_custom_view
WHERE
  quantity > 0
  AND (return_reasons IS NULL OR trim(return_reasons) = "")
  AND try_to_timestamp(customer_request_ship_date_parsed, 'yyyyMMdd') <= current_date()
  AND (
    shortage > 0
    OR delay_days > 0
  )
ORDER BY
  created_date DESC
    """
)


print("Count of Records Before Filtering: ", base_df.count())

# Only track those discrepancies for which we have the warehouse information
three_pl_df = spark.table(THREE_PL_TABLE)

base_df = base_df.join(
    F.broadcast(three_pl_df),
    on=[
        base_df["storage"] == three_pl_df["storage"],
    ],
    how="semi",
)

print("Count of Records After Joining with 3PLs information data: ", base_df.count())

if spark.catalog.tableExists(OUTPUT_TRANSIENT_TABLE):
    # We will remove those records that are already present in the table
    transient_df = spark.table(OUTPUT_TRANSIENT_TABLE)
    base_df = base_df.join(
        transient_df,
        on=[
            base_df["id"] == transient_df["id"],
        ],
        how="anti",
    )
    print("Count of Records After Anti Join: ", base_df.count())

base_df.write.mode("append").saveAsTable(OUTPUT_TRANSIENT_TABLE)

# COMMAND ----------

print(spark.table(OUTPUT_TRANSIENT_TABLE).count())

print(spark.table(OUTPUT_TRANSIENT_TABLE).filter("processed = FALSE").count())