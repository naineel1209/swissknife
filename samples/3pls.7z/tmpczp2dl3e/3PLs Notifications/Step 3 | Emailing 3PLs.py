# Databricks notebook source
from pyspark.sql import functions as F
import os
import pandas as pd
import pandas as pd
import datetime as dt
import boto3
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from html import escape
import re

TEMP_FILE_LOCATION = f"/Workspace/Temp Files/3PLs_Notifications"
os.makedirs(TEMP_FILE_LOCATION, exist_ok=True)

OUTPUT_TRANSIENT_TABLE = "data_team_test.test_schema.logistics_transient_table"
THREE_PL_TABLE = "data_team_test.test_schema.three_pl_information"
SENDER = "Logistics@zuru.com"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Date Handlers

# COMMAND ----------

def get_start_end_date_from_week_year_identifier(week_year_identifier):
    """
    Extract the start and end dates from the week_year_identifier string in string format.
    """

    weekofyear, year = week_year_identifier.split("-")

    # Calculate start (Monday) and end (Sunday) of the given ISO week
    start_date = pd.to_datetime(f"{year}-W{int(weekofyear)}-1", format="%G-W%V-%u")
    end_date = start_date + dt.timedelta(days=6)
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")

    return start_str, end_str

# COMMAND ----------

# MAGIC %md
# MAGIC ## Attachments Generator

# COMMAND ----------

def attachments_generator(collected_list, week_year_identifier, storage):
    """
    Generate attachments for email notifications
    """
    pd_df = pd.DataFrame(collected_list)

    start_date, end_date = get_start_end_date_from_week_year_identifier(week_year_identifier)

    short_stocked_file_name = f"zuru_short_stocked_{start_date}_to_{end_date}.csv"
    delayed_file_name = f"zuru_delayed_{start_date}_to_{end_date}.csv"

    pd_df["shortage"] = pd.to_numeric(pd_df["shortage"], errors="coerce")
    pd_df["delay_days"] = pd.to_numeric(pd_df["delay_days"], errors="coerce")

    short_stocked_df = pd_df[(pd_df["shortage"] > 0)]
    delayed_df = pd_df[(pd_df["delay_days"] > 0)]

    # Saved the dataframe as a CSV file
    # Once - for short stocked
    short_stocked_file_name = os.path.join(TEMP_FILE_LOCATION, short_stocked_file_name)
    short_stocked_df.to_csv(short_stocked_file_name, index=False)

    # Once - for delayed
    delayed_file_name = os.path.join(TEMP_FILE_LOCATION, delayed_file_name)
    delayed_df.to_csv(delayed_file_name, index=False)

    return {
        "short_stocked_file_name": short_stocked_file_name,
        "delayed_file_name": delayed_file_name,
        "short_stocked_count": short_stocked_df.shape[0],
        "delayed_count": delayed_df.shape[0],
    }

# COMMAND ----------

# MAGIC %md
# MAGIC ## Email Signatures and Templates

# COMMAND ----------

def get_zuru_email_signature():
    """
    Returns the Logistics Team Zuru email signature.
    """
    return """
      <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <!-- Outlook-specific styles -->
  <!--[if gte mso 9]>
  <style type="text/css">
    p, a, li, td, body, table, tr {
      line-height: 100%;
      margin: 0;
      padding: 0;
    }
  </style>
  <![endif]-->


  <table id="zuru-output-sig" border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;line-height:1;font-size:12px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse; width:700px;">
    <tbody>
      <tr>
        <td style="padding:0!important;">
          <table id="inner-table" border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;line-height:1;font-size:12px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse;">
            <tbody>
              <tr>
                <td width="183" style="padding:0;padding-right:10px;">
                  <table border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;line-height:1;font-size:12px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse;">
                    <tbody>
                      <tr>
                        <td style="border-collapse:collapse;line-height:1;padding:0!important;">
                          <a style="font-size:12px;line-height:1;" target="_blank" rel="nofollow" href="https://zuru.com/"><img decoding="async" id="signatureImage" width="188" height="94" style="width:188.16px;height:94.08px;max-width:188.16px;max-height:94.08px;" alt="ZURU Logo" border="0" src="https://team.zuru.com/wp-content/uploads/2025/02/zuru-signature.jpg"></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
                <td style="padding:0!important;">
                  <table border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;font-size:12px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse;">
                    <tbody>
                      <tr>
                        <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-style:normal;font-weight:700;padding:0!important;">
                          <span style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:700;color:#000001;display:inline;">Logistics Team</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;font-weight:400;padding:0!important;padding-bottom:10px;">
                          <span style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:400;color:#000000;display:inline;">Logistics Coordinator</span>
                        </td>
                      </tr>
                      <tr>
  <td style="padding:0!important; height:10px;">
    <!-- Empty space -->
  </td>
</tr>
                      <tr>
                        <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;font-weight:400;padding:0!important;padding-bottom:10px;">
                          <span class="address" style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:400;color:#000000;display:inline;"></span>
                        </td>
                      </tr>
                      <tr>
                        <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;font-weight:400;padding:0!important;">
                          <span class="address" style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:400;color:#000000;display:inline;">Level 4, Building A, 167 Victoria Street West, Auckland Central, Auckland 1010, New Zealand</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:0!important; vertical-align:top;">
                          <table border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;line-height:1;font-size:12px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse;">
                            <tbody>
                              <tr>
                                <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-style:normal;font-weight:400;padding:0;padding-right:10px;">
                                   <span style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:700;color:#000001;display:inline;">Part of the ZURU Group</span>
                                </td>
                                
                                <td style="padding:0;padding-right:10px; vertical-align:top;">
                                  <a target="_blank" rel="nofollow" href="http://www.zuru.com/" style="font-family:Helvetica,Arial,sans-serif;font-size:12px;font-style:normal;line-height:12pt;font-weight:400;color:#000000;display:inline;text-decoration:underline;">zuru.com</a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:0!important;">
          <table id="inner-table" border="0" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;line-height:1;font-size:10px;padding:0!important;border-spacing:0;margin:0;border-collapse:collapse;">
            <tbody>
            <tr>
  <td style="padding:0!important; height:10px;">
    <!-- Empty space -->
  </td>
</tr>
              <tr>
                <td style="border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-style:normal;line-height:12px;font-weight:400;padding:0!important;">

                  <span style="font-family:Helvetica,Arial,sans-serif;font-size:10px;font-style:normal;line-height:12px;font-weight:400;color:#b4b4b4;display:inline;">This email may contain confidential/privileged information and is intended solely for the named recipient(s), therefore information herein may not be passed on without the explicit written consent of the author. If you are not the intended recipient you may not disclose, copy, distribute or retain any part of this message or attachments. If you have received this e-mail in error please notify the sender immediately via e-mail and delete the message from your records. Any views or opinions expressed are solely those of the author and do not necessarily represent those of The ZURU Group collectively and/or its subsidiaries.</span>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>"""

# COMMAND ----------

def _sanitize_filename_for_display(name: str) -> str:
    """Return a trimmed, safe display filename. Keep extension if present."""
    if not name:
        return ""
    safe = re.sub(r"[\x00-\x1f\x7f]+", "", name).strip()
    safe = re.sub(r"\s+", " ", safe)
    return safe

# COMMAND ----------

def generate_weekly_fulfillment_email(
    contact_name: str,
    week_year_identifier: str,
    current_warehouse: str,
    shortage_count: int,
    delay_count: int,
    short_stocked_file_name: str,
    delayed_file_name: str,
    storage: str,
    storage_desc: str,
):
    """
    Generate plain-text and HTML weekly fulfillment discrepancy email:
    - Facility center and period on separate lines with bold emphasis
    - Filenames displayed without extension and emphasized
    """

    # Helper assumed to exist
    start_date, end_date = get_start_end_date_from_week_year_identifier(
        week_year_identifier
    )

    subject = f"Order Fulfillment Discrepancies: IMMEDIATE RESPONSE REQUIRED ({start_date} to {end_date})"

    # Prepare display filenames without extension
    def strip_extension(file_path: str) -> str:
        return os.path.splitext(os.path.basename(file_path))[0]

    short_display = strip_extension(short_stocked_file_name) if short_stocked_file_name else ""
    delay_display = strip_extension(delayed_file_name) if delayed_file_name else ""

    attachments = []
    if shortage_count and short_stocked_file_name:
        attachments.append(short_stocked_file_name)
    if delay_count and delayed_file_name:
        attachments.append(delayed_file_name)

    esc = lambda s: escape(s) if s else ""

    # -------------------
    # HTML body
    # -------------------
    html_lines = [
        f"<p>Dear {esc(contact_name)},</p>",
        (
            "<p>We are reaching out to inform you about discrepancies observed in the "
            "order fulfillment process for your facility during the specified period. "
            "These discrepancies require your prompt attention and action.</p>"
        ),
        (
            f"<p>Facility Center: <strong>{esc(current_warehouse)}</strong><br>"
            f"Period: <strong>{esc(start_date)} to {esc(end_date)}</strong></p>"
        ),
        "<p>Identified issues:</p>"
    ]

    issue_index = 1
    if shortage_count > 0:
        html_lines.append(
            f"<p>{issue_index}. Short Stock ({shortage_count} items) - File: <strong>{esc(short_display)}</strong></p>"
        )
        issue_index += 1
    if delay_count > 0:
        html_lines.append(
            f"<p>{issue_index}. Delayed ({delay_count} items) - File: <strong>{esc(delay_display)}</strong></p>"
        )
    if shortage_count == 0 and delay_count == 0:
        html_lines.append("<p>No shortages or delays identified for this period.</p>")

    html_lines.extend([
        "<p>Please review these issues and respond with details, corrective actions, "
        "and estimated resolution times.</p>",
        "<p>Thank you for your prompt attention.</p>",
        "<p>Best regards,<br>Logistics Department<br>Zuru</p>"
    ])

    html_body = "\n".join(html_lines)

    # -------------------
    # Text body
    # -------------------
    text_lines = [
        f"Dear {contact_name},\n",
        f"Facility Center: {current_warehouse}\n"
        f"Period: {start_date} to {end_date}\n",
        "Identified issues:"
    ]

    issue_index = 1
    if shortage_count > 0:
        text_lines.append(
            f"{issue_index}. Short Stock ({shortage_count} items) - File: {short_display}"
        )
        issue_index += 1
    if delay_count > 0:
        text_lines.append(
            f"{issue_index}. Delayed ({delay_count} items) - File: {delay_display}"
        )
    if shortage_count == 0 and delay_count == 0:
        text_lines.append("No shortages or delays identified for this period.")

    text_lines.extend([
        "\nPlease review these issues and respond with details, corrective actions, and estimated resolution times.\n",
        "Thank you for your prompt attention.\n",
        "Best regards,\nLogistics Department\nZuru\n"
    ])

    text_body = "\n".join(text_lines)

    return {
        "subject": subject,
        "html_body": html_body + get_zuru_email_signature(),
        "text_body": text_body,
        "attachments": attachments,
    }


# COMMAND ----------

def process_record(row):
    """
    Process a single record from the unprocessed DataFrame and send emails to the 3PL contact person

    Args:
        storage (str): Storage Key
        collected_list (array): Array of structs containing details of each item in the order
        Current_Warehouse (str): Current Warehouse/Facility name
        contact_name (str): 3PL contact person name
    Returns:
        None
    """

    (
        storage,
        collected_list,
        Current_Warehouse,
        contact_name,
        week_year_identifier,
        storage_desc,
    ) = (
        row["storage"],
        row["collected_list"],
        row["Current_Warehouse"],
        row["contact_name"],
        row["week_year_identifier"],
        row["storage_desc"],
    )

    # Generate the 2 attachments for the mail
    attachment_details = attachments_generator(
        collected_list=collected_list,
        week_year_identifier=week_year_identifier,
        storage=storage,
    )

    email_details = generate_weekly_fulfillment_email(
        **{
            "contact_name": contact_name,
            "week_year_identifier": week_year_identifier,
            "current_warehouse": Current_Warehouse,
            "shortage_count": attachment_details["short_stocked_count"],
            "delay_count": attachment_details["delayed_count"],
            "short_stocked_file_name": attachment_details["short_stocked_file_name"],
            "delayed_file_name": attachment_details["delayed_file_name"],
            "storage": storage,
            "storage_desc": storage_desc,
        }
    )


    return email_details

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conversions from DF to Rows in Dict

# COMMAND ----------

def convert_to_rows_dict(df):
    """
    This function converts the dataframe into a dictionary of rows, where each row is a dictionary of column names and values.
    """

    return [row.asDict(recursive=True) for row in df.collect()]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Send SES Emails

# COMMAND ----------

def send_ses_email_with_attachments(
    sender,
    recipients,
    subject,
    body_text,
    body_html,
    attachment_paths,
    region="ap-southeast-2",
    configuration_set_name="email-test-configuration-set",
):
    """
    Sends an email via AWS SES with multiple attachments.

    Parameters:
    - sender: Email sender address (str)
    - recipients: List of recipient email addresses (list of str)
    - subject: Email subject (str)
    - body_text: Plain text body content (str)
    - body_html: HTML body content (str)
    - attachment_paths: List of file paths to attachments (list of str)
    - aws_access_key: AWS access key (str)
    - aws_secret_key: AWS secret key (str)
    - region: AWS region name (str, default: "ap-southeast-2")
    - configuration_set_name: SES configuration set name (str or None)

    Returns:
    - SES send_raw_email response dict
    """

    aws_access_key = dbutils.secrets.get("AWS-Admin", "access-key")
    aws_secret_key = dbutils.secrets.get("AWS-Admin", "secret-key")

    # Create AWS session
    session = boto3.Session(
        aws_access_key_id=aws_access_key,
        aws_secret_access_key=aws_secret_key,
        region_name=region,
    )

    # Create message
    msg = MIMEMultipart("mixed")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)

    # Body part (text and HTML)
    msg_body = MIMEMultipart("alternative")
    msg_body.attach(MIMEText(body_text, "plain"))
    msg_body.attach(MIMEText(body_html, "html"))
    msg.attach(msg_body)

    # Add attachments
    for attachment_path in attachment_paths:
        with open(attachment_path, "rb") as file:
            part = MIMEApplication(file.read())
        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=os.path.basename(attachment_path),
        )
        msg.attach(part)

    # Send via SES
    client = session.client("ses")

    # Prepare parameters
    send_params = {
        "Source": sender,
        "Destinations": recipients,
        "RawMessage": {"Data": msg.as_string()},
    }

    # Add optional configuration set
    if configuration_set_name:
        send_params["ConfigurationSetName"] = configuration_set_name
        send_params["Tags"] = [
            {"Name": "ConfigurationSetName", "Value": configuration_set_name}
        ]

    response = client.send_raw_email(**send_params)

    print(f"Detailed Response: {response} \n")
    print(f"Email sent! Message ID: {response['MessageId']}")

    return response


# COMMAND ----------

# MAGIC %md
# MAGIC ## Update the Transient Table rows - so that we have a record of the message id referencing it --

# COMMAND ----------

def update_processed_rows(row, message_id):
    """
    Update rows in OUTPUT_TRANSIENT_TABLE as processed with message_id
    for auditing purposes.
    """
    try:
        collected_list = row["collected_list"]

        # Convert all IDs to string for safe SQL formatting
        transient_records_rows = [str(item["id"]) for item in collected_list]

        # Build SQL safely
        sql_query_where_clause = f"id IN ({','.join(transient_records_rows)})"
        sql_query_update = f"""
            UPDATE {OUTPUT_TRANSIENT_TABLE}
            SET processed = TRUE,
                message_id = '{message_id}'
            WHERE {sql_query_where_clause}
        """
        spark.sql(sql_query_update)

        return True
    except Exception as e:
        print(f"Error: {e}")
        return False


# COMMAND ----------

# MAGIC %md
# MAGIC ## Main
# MAGIC
# MAGIC ### Workflow
# MAGIC
# MAGIC 1. We get the `unprocessed_df` which contains the records which are unprocessed and the `three_pl_df` the static df we have for 3PL identification
# MAGIC 2. Then, we group the `unprocessed_df` on 2 columns -  week_year_identifier and storage - so, we are sending out one email per storage and per week_year
# MAGIC     ```python
# MAGIC     F.concat(
# MAGIC         F.weekofyear("created_date"),
# MAGIC         F.lit("-"),
# MAGIC         F.year("created_date")
# MAGIC     ).alias("week_year_identifier"),
# MAGIC     F.col("storage")
# MAGIC     ```
# MAGIC
# MAGIC 3. Then, we join the grouped_unprocessed_df to the 3PLs df so that we can get the sending details for the same

# COMMAND ----------

# DBTITLE 1,Main
unprocessed_df = spark.table(OUTPUT_TRANSIENT_TABLE).filter(
    (F.col("processed") == False) &
    (F.col("created_date") >= F.date_sub(F.current_date(), 7)) &
    (F.col("created_date") <= F.current_date())
)

three_pl_df = spark.table(THREE_PL_TABLE).alias("three_pl_df")

# COMMAND ----------

# %sql
# SELECT
#   concat(weekofyear(created_date), '-', year(created_date)) AS week_year_identifier,
#   storage,
#   COLLECT_LIST(
#     NAMED_STRUCT(
#       'id',
#       id,
#       'sku',
#       sku,
#       'long_desc',
#       long_desc,
#       'brand',
#       brand,
#       'brand_desc',
#       brand_desc,
#       'sales_order',
#       sales_order,
#       'deliv_note_no',
#       deliv_note_no,
#       'delivery_address',
#       delivery_address,
#       'customer_po_num',
#       customer_po_num,
#       'cutomer_name_sold_to',
#       cutomer_name_sold_to,
#       'quantity',
#       quantity,
#       'shipping_quantity',
#       shipping_quantity,
#       'shortage',
#       shortage,
#       'customer_request_ship_date',
#       customer_request_ship_date,
#       'customer_request_ship_date_parsed',
#       customer_request_ship_date_parsed,
#       'actual_shipping_date',
#       actual_shipping_date,
#       'delay_days',
#       delay_days,
#       'storage',
#       storage,
#       'storage_desc',
#       storage_desc,
#       'item_No',
#       item_No,
#       'sales_org',
#       sales_org,
#       'created_date',
#       created_date,
#       'return_reasons',
#       return_reasons,
#       'key_type',
#       key_type,
#       'key_value',
#       key_value
#     )
#   ) AS collected_list
# FROM
#   unprocessed_df
# GROUP BY
#   concat(weekofyear(created_date), '-', year(created_date)),
#   storage
# ORDER BY
#   size(collected_list) DESC;

# COMMAND ----------

"""
Grouping By The Data: 
    - The specific conditions for grouping by the date
        - For the same `created_date`, `key_type`, `key_value`, `storage` - we will send out a single mail
        - Use `collect_list` as an array struct to collect all the details necessary for the mail
"""

unprocessed_df = (
    unprocessed_df.groupBy(
        F.concat(
            F.weekofyear("created_date"),
            F.lit("-"),
            F.year("created_date")
        ).alias("week_year_identifier"),
        F.col("storage")
    )
    .agg(
        F.collect_list(
            F.struct(
                F.col("id").alias("id"),
                F.col("sku").alias("sku"),
                F.col("long_desc").alias("long_desc"),
                F.col("brand").alias("brand"),
                F.col("brand_desc").alias("brand_desc"),
                F.col("sales_order").alias("sales_order"),
                F.col("deliv_note_no").alias("deliv_note_no"),
                F.col("delivery_address").alias("delivery_address"),
                F.col("customer_po_num").alias("customer_po_num"),
                F.col("cutomer_name_sold_to").alias("cutomer_name_sold_to"),
                F.col("quantity").alias("quantity"),
                F.col("shipping_quantity").alias("shipping_quantity"),
                F.col("shortage").alias("shortage"),
                F.col("customer_request_ship_date").alias("customer_request_ship_date"),
                F.col("customer_request_ship_date_parsed").alias("customer_request_ship_date_parsed"),
                F.col("actual_shipping_date").alias("actual_shipping_date"),
                F.col("delay_days").alias("delay_days"),
                F.col("storage").alias("storage"),
                F.col("storage_desc").alias("storage_desc"),
                F.col("item_No").alias("item_No"),
                F.col("sales_org").alias("sales_org"),
                F.col("created_date").alias("created_date"),
                F.col("return_reasons").alias("return_reasons"),
                F.col("key_type").alias("key_type"),
                F.col("key_value").alias("key_value")
            )
        ).alias("collected_list")
    )
    .orderBy(F.size("collected_list").desc())
    .alias("unprocessed_df")
)

# COMMAND ----------

"""
Merge it with the three_pl_df to get the contact details for the warehouse
"""

unprocessed_df = unprocessed_df.join(
    F.broadcast(three_pl_df),
    on=["storage"],
    how="inner",
).select(
    "unprocessed_df.*",
    "three_pl_df.Current_Warehouse",
    "three_pl_df.contact_name",
    "three_pl_df.contact_email",
    "three_pl_df.storage_desc",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Process each row of the unprocessed_df
# MAGIC
# MAGIC
# MAGIC ### Workflow
# MAGIC - Process each row
# MAGIC     - Generate Attachments for each row (2 per each row)
# MAGIC     - Draft a mail subject and body for each row
# MAGIC     - We will send out mails to the 3PLs using the contact email - 

# COMMAND ----------

unprocessed_rows = convert_to_rows_dict(unprocessed_df)

# COMMAND ----------

for row in unprocessed_rows:
    email_details = process_record(row)

    # Send emails on the details
    sent_email_response = send_ses_email_with_attachments(
        sender=SENDER,
        recipients=(
            [row["contact_email"]]
            if row["contact_email"] != "vlad@zuru.com"
            else ["naineel.soyantar@zuru.com", "tushar@zuru.com"]
        ),
        subject=email_details["subject"],
        body_text=email_details["text_body"],
        body_html=email_details["html_body"],
        attachment_paths=[
            os.path.join(
                TEMP_FILE_LOCATION,
                os.path.basename(row_name),
            )
            for row_name in email_details["attachments"]
        ],
    )

    # Update the messages as - processed and save its message-id in our transient tables:
    for attempt in range(3):
        print(f"Attempt {attempt + 1} of 3")
        if update_processed_rows(row, sent_email_response["MessageId"]):
            break

    print(" = = = = = = = = =")